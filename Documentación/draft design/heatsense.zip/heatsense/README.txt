A Pen created at CodePen.io. You can find this one at http://codepen.io/Mongeed/pen/IuBLt.

 A simple log-in screen I pretty much made out of boredom. Style is based on google's login which is one of my favorite login's. Tried to keep it minimalistic, I think it worked.